﻿namespace Dbex
{
    partial class AdditemForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            eidtextBox = new TextBox();
            enametextBox = new TextBox();
            eloctextBox = new TextBox();
            edestextBox = new TextBox();
            addevntbutton = new Button();
            label6 = new Label();
            edateTimePicker = new DateTimePicker();
            BackTobutton = new Button();
            organizeridlabel7 = new Label();
            organizeridevtextBox1 = new TextBox();
            vieweventgobutton = new Button();
            label7 = new Label();
            eventtimetextBox2 = new TextBox();
            label8 = new Label();
            locationaddidtextBox11 = new TextBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(276, 65);
            label1.Name = "label1";
            label1.Size = new Size(73, 20);
            label1.TabIndex = 0;
            label1.Text = "1.Event Id";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(38, 186);
            label2.Name = "label2";
            label2.Size = new Size(100, 20);
            label2.TabIndex = 1;
            label2.Text = "3.Event Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(38, 284);
            label3.Name = "label3";
            label3.Size = new Size(117, 20);
            label3.TabIndex = 2;
            label3.Text = "5.Event Location";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(38, 239);
            label4.Name = "label4";
            label4.Size = new Size(92, 20);
            label4.TabIndex = 3;
            label4.Text = "4.Event Date";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(462, 291);
            label5.Name = "label5";
            label5.Size = new Size(136, 20);
            label5.TabIndex = 4;
            label5.Text = "8.Event Description";
            // 
            // eidtextBox
            // 
            eidtextBox.Location = new Point(424, 62);
            eidtextBox.Name = "eidtextBox";
            eidtextBox.Size = new Size(125, 27);
            eidtextBox.TabIndex = 5;
            // 
            // enametextBox
            // 
            enametextBox.Location = new Point(166, 183);
            enametextBox.Name = "enametextBox";
            enametextBox.Size = new Size(125, 27);
            enametextBox.TabIndex = 6;
            // 
            // eloctextBox
            // 
            eloctextBox.Location = new Point(184, 284);
            eloctextBox.Name = "eloctextBox";
            eloctextBox.Size = new Size(125, 27);
            eloctextBox.TabIndex = 7;
            // 
            // edestextBox
            // 
            edestextBox.Location = new Point(639, 291);
            edestextBox.Name = "edestextBox";
            edestextBox.Size = new Size(125, 27);
            edestextBox.TabIndex = 8;
            // 
            // addevntbutton
            // 
            addevntbutton.Location = new Point(92, 409);
            addevntbutton.Name = "addevntbutton";
            addevntbutton.Size = new Size(94, 29);
            addevntbutton.TabIndex = 10;
            addevntbutton.Text = "Add Event";
            addevntbutton.UseVisualStyleBackColor = true;
            addevntbutton.Click += addevntbutton_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(337, 15);
            label6.Name = "label6";
            label6.Size = new Size(125, 20);
            label6.TabIndex = 11;
            label6.Text = "Add or Edit Event";
            // 
            // edateTimePicker
            // 
            edateTimePicker.Location = new Point(166, 234);
            edateTimePicker.Name = "edateTimePicker";
            edateTimePicker.Size = new Size(250, 27);
            edateTimePicker.TabIndex = 13;
            // 
            // BackTobutton
            // 
            BackTobutton.Location = new Point(621, 409);
            BackTobutton.Name = "BackTobutton";
            BackTobutton.Size = new Size(129, 29);
            BackTobutton.TabIndex = 14;
            BackTobutton.Text = "Back To Menu";
            BackTobutton.UseVisualStyleBackColor = true;
            BackTobutton.Click += BackTobutton_Click;
            // 
            // organizeridlabel7
            // 
            organizeridlabel7.AutoSize = true;
            organizeridlabel7.Location = new Point(276, 120);
            organizeridlabel7.Name = "organizeridlabel7";
            organizeridlabel7.Size = new Size(104, 20);
            organizeridlabel7.TabIndex = 15;
            organizeridlabel7.Text = "2.Organizer ID";
            // 
            // organizeridevtextBox1
            // 
            organizeridevtextBox1.Location = new Point(424, 113);
            organizeridevtextBox1.Name = "organizeridevtextBox1";
            organizeridevtextBox1.Size = new Size(125, 27);
            organizeridevtextBox1.TabIndex = 16;
            organizeridevtextBox1.TextChanged += textBox1_TextChanged;
            // 
            // vieweventgobutton
            // 
            vieweventgobutton.Location = new Point(367, 409);
            vieweventgobutton.Name = "vieweventgobutton";
            vieweventgobutton.Size = new Size(133, 29);
            vieweventgobutton.TabIndex = 17;
            vieweventgobutton.Text = "View Location";
            vieweventgobutton.UseVisualStyleBackColor = true;
            vieweventgobutton.Click += vieweventgobutton_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(462, 248);
            label7.Name = "label7";
            label7.Size = new Size(134, 20);
            label7.TabIndex = 18;
            label7.Text = "7.Morning/Evening";
            // 
            // eventtimetextBox2
            // 
            eventtimetextBox2.Location = new Point(639, 241);
            eventtimetextBox2.Name = "eventtimetextBox2";
            eventtimetextBox2.Size = new Size(125, 27);
            eventtimetextBox2.TabIndex = 19;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(464, 208);
            label8.Name = "label8";
            label8.Size = new Size(94, 20);
            label8.TabIndex = 20;
            label8.Text = "6.Location Id";
            // 
            // locationaddidtextBox11
            // 
            locationaddidtextBox11.Location = new Point(639, 201);
            locationaddidtextBox11.Name = "locationaddidtextBox11";
            locationaddidtextBox11.Size = new Size(125, 27);
            locationaddidtextBox11.TabIndex = 21;
            // 
            // AdditemForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(locationaddidtextBox11);
            Controls.Add(label8);
            Controls.Add(eventtimetextBox2);
            Controls.Add(label7);
            Controls.Add(vieweventgobutton);
            Controls.Add(organizeridevtextBox1);
            Controls.Add(organizeridlabel7);
            Controls.Add(BackTobutton);
            Controls.Add(edateTimePicker);
            Controls.Add(label6);
            Controls.Add(addevntbutton);
            Controls.Add(edestextBox);
            Controls.Add(eloctextBox);
            Controls.Add(enametextBox);
            Controls.Add(eidtextBox);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "AdditemForm";
            Text = "AdditemForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox eidtextBox;
        private TextBox enametextBox;
        private TextBox eloctextBox;
        private TextBox edestextBox;
        private Button addevntbutton;
        private Label label6;
        private DateTimePicker edateTimePicker;
        private Button BackTobutton;
        private Label organizeridlabel7;
        private TextBox organizeridevtextBox1;
        private Button vieweventgobutton;
        private Label label7;
        private TextBox eventtimetextBox2;
        private Label label8;
        private TextBox locationaddidtextBox11;
    }
}